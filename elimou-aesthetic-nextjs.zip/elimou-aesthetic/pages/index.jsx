import React from "react";
import AppLayout from "../components/AppLayout";
import { Button } from "../components/ui/button";

export default function HomePage() {
  const INSTAGRAM_URL = "https://instagram.com/elimou_aesthetic";
  const CALL_URL = "tel:+447828126991";
  const WHATSAPP_URL = "https://wa.me/447828126991";

  return (
    <AppLayout>
      <section style={{padding:"80px 16px", textAlign:"center", background:"#fff0f5"}}>
        <h1 style={{fontSize:36, marginBottom:8}}>London’s Premium Skin & Aesthetic Care</h1>
        <p style={{fontSize:18, color:"#444", marginBottom:20}}>زیبایی، سهم شما از زندگی‌ست.</p>
        <div style={{display:"flex", gap:8, justifyContent:"center", flexWrap:"wrap"}}>
          <Button asChild size="lg"><a href={CALL_URL}>Call Now</a></Button>
          <Button asChild size="lg" variant="outline"><a href={WHATSAPP_URL} target="_blank" rel="noreferrer">WhatsApp</a></Button>
          <Button asChild size="lg" variant="secondary"><a href={INSTAGRAM_URL} target="_blank" rel="noreferrer">Instagram DM</a></Button>
        </div>
      </section>

      <section style={{padding:"48px 16px", maxWidth:1100, margin:"0 auto"}} id="treatments">
        <h2 style={{fontSize:28, textAlign:"center", marginBottom:24}}>Featured Treatments</h2>
        <ul style={{display:"grid", gridTemplateColumns:"repeat(auto-fit, minmax(220px, 1fr))", gap:16, listStyle:"none", padding:0}}>
          {[
            ["PRP Therapy","/treatments/prp-therapy"],
            ["PRF Under-Eye","/treatments/prf-under-eye"],
            ["Botox","/treatments/botox"],
            ["Dermal Fillers","/treatments/dermal-fillers"],
            ["Profhilo","/treatments/profhilo"],
            ["Hydrafacial","/treatments/hydrafacial"],
            ["Fat Dissolving","/treatments/fat-dissolving"],
            ["Microneedling","/treatments/microneedling"]
          ].map(([title, href]) => (
            <li key={href} style={{border:"1px solid #eee", borderRadius:12, padding:16}}>
              <h3 style={{marginTop:0}}>{title}</h3>
              <a href={href}>View</a>
            </li>
          ))}
        </ul>
      </section>

      <section id="contact" style={{padding:"48px 16px", background:"#fafafa"}}>
        <div style={{maxWidth:1100, margin:"0 auto"}}>
          <h2 style={{fontSize:28, marginBottom:16}}>Find Us</h2>
          <p>Address: 639 Holloway Rd, Archway, London N19 5SS</p>
          <p>Phone: 07828126991 — Email: elimou2590@gmail.com</p>
          <div style={{display:"flex", gap:8, marginTop:12, flexWrap:"wrap"}}>
            <Button asChild><a href={CALL_URL}>Call Now</a></Button>
            <Button asChild variant="outline"><a href={WHATSAPP_URL} target="_blank" rel="noreferrer">WhatsApp</a></Button>
            <Button asChild variant="secondary"><a href={INSTAGRAM_URL} target="_blank" rel="noreferrer">Instagram DM</a></Button>
          </div>
          <div id="map" style={{marginTop:16}}>
            <div style={{border:"1px solid #eee", borderRadius:12, height:320, display:"grid", placeItems:"center"}}>Map placeholder</div>
          </div>
        </div>
      </section>
    </AppLayout>
  );
}